# @jjuidev/styles

The design system as CSS for Tailwind CSS 4: semantic color tokens with a light and a dark value, skins, text roles,
layout utilities, and the theme runtime that applies them. Your app's Tailwind compiles it, so there is no prebuilt
stylesheet and no second copy of Tailwind.

## Install

The package is not on npm. Install the tarball of the version you want:

```sh
pnpm add ./jjuidev-styles-<version>.tgz
```

`tailwindcss` ^4.3 is a required peer dependency.

## Use

Import Tailwind first, then the design system, in your app's CSS entry:

```css
@import 'tailwindcss';
@import '@jjuidev/styles/styles.css';
```

Then style with the semantic classes, never a palette step: `bg-primary text-primary-foreground`, `text-muted`,
`border-default`, `bg-raised`. States are tokens (`hover:bg-primary-hover`), and dark mode needs no `dark:` for color.
The full token reference, with values for every skin, is on the [documentation site](https://design-system.jjuidev.com).

## Entry points

| Import                       | Gives                                                                           |
| ---------------------------- | ------------------------------------------------------------------------------- |
| `@jjuidev/styles/styles.css` | The one CSS entry: tokens, skins, text roles, layout and focus utilities        |
| `@jjuidev/styles/variants`   | `cn` and `tv`, `tailwind-merge` and `tailwind-variants` set up for these tokens |
| `@jjuidev/styles/theme`      | The framework-free theme runtime: theme and skin store, preference cookies      |
| `@jjuidev/styles/cli`        | The skin contrast check as functions                                            |

The `skin-check` command checks a skin file against the contrast contract (WCAG 2.2 AA):

```sh
pnpm exec skin-check [--separation] <skin.css> [skin.css ...]
```
