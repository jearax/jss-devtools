# @jjuidev/react

React components built on `@jjuidev/styles`, shipped compiled with their CSS in `@layer components`.

| Export                      | For                                                       |
| --------------------------- | --------------------------------------------------------- |
| `ThemeProvider`, `useTheme` | Theme (light, dark, system) and skin, kept in cookies     |
| `ThemeToggle`, `SkinToggle` | Controls for the theme and the skin                       |
| `Button`, `ButtonCopy`      | Actions; `ButtonCopy` copies a value to the clipboard     |
| `Dialog`, `Popover`         | Compound overlays built on Base UI                        |
| `Logo`, `useFavicon`        | The brand mark, and a favicon that follows theme and skin |

## Install

The packages are not on npm. Install both tarballs:

```jsonc
// package.json
{
  "dependencies": {
    "@jjuidev/react": "file:./vendor/jjuidev-react-<version>.tgz",
    "@jjuidev/styles": "file:./vendor/jjuidev-styles-<version>.tgz"
  }
}
```

`@jjuidev/react` depends on `@jjuidev/styles` by version, so point that dependency at the tarball too, or pnpm looks
for it on the npm registry and the install fails. pnpm 11 reads overrides from `pnpm-workspace.yaml`, not from
`package.json`:

```yaml
# pnpm-workspace.yaml
overrides:
  '@jjuidev/styles': file:./vendor/jjuidev-styles-<version>.tgz
```

Peer dependencies: `react` and `react-dom` ^19, and `tailwindcss` ^4.3.

## Use

```css
@import 'tailwindcss';
@import '@jjuidev/styles/styles.css';
@import '@jjuidev/react/styles.css';
```

```tsx
import { Button, ThemeProvider } from '@jjuidev/react';

const App = () => {
  return (
    <ThemeProvider>
      <Button>Deploy</Button>
    </ThemeProvider>
  );
};
```

Brand icons for a web manifest or `<link rel="icon">` are under `@jjuidev/react/brand/*`.
