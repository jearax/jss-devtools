# jjuidev design system

Design tokens and rules for building UI with Tailwind CSS v4. Tailwind is the
base; a small semantic layer sits on top, so a component says what a color or a
text role **does**, not which shade it is. Every token has a light and a dark
value, and every new text or UI pairing has to meet WCAG 2.2 AA in both.

This is a personal project and a learning vehicle, not a product. It is built as
the `@jjuidev/design-system` package (`pnpm build:lib`), which a zone installs for
the components, the theme and skin provider, and the stylesheets.

## Use as a package

Import one stylesheet, never both:

```ts
import '@jjuidev/design-system/styles.css'; // precompiled, no build step
// or, in a host that runs Tailwind v4: @import '@jjuidev/design-system/tailwind.css';
```

```tsx
import { defineSkin, ThemeProvider } from '@jjuidev/design-system';

<ThemeProvider skins={[defineSkin({ id: 'shop-ocean', label: 'Ocean' })]}>…</ThemeProvider>;
```

The package carries no fonts; the host loads Be Vietnam Pro, Lora and Cascadia Code, or the stacks fall
back to system fonts. Either link the stylesheet this repository's `index.html` links (and allow
`fonts.googleapis.com` and `fonts.gstatic.com` in the CSP), or load them the host's own way and point the
font tokens at the result. With `next/font`, whose family names are generated:

```css
:root {
	--font-sans: var(--font-be-vietnam-pro), system-ui, sans-serif;
	--font-serif: var(--font-lora), Georgia, serif;
	--font-mono: var(--font-cascadia-code), ui-monospace, monospace;
}
```

Every class of both stylesheets reads `var(--font-*)`, so these three variables are the whole contract.

A zone's skin file is checked with `jds skin check src/skin-shop-ocean.css`. Why and how:
[`docs/decisions/0010-skins-and-styles-in-library-mode.md`](docs/decisions/0010-skins-and-styles-in-library-mode.md).

## Quickstart

Requires Node 24 and pnpm 11.

```bash
pnpm install    # install dependencies
pnpm dev        # Vite dev server
pnpm build      # typecheck, then build the standalone mode into dist/
pnpm preview    # serve the production build
```

### Deploy modes

The same source builds in two production modes, chosen at build time, because
Vite fixes its public base path then. Each mode is its own image:

```bash
pnpm run build --mode standalone   # served at the root of design-system.jjuidev.com
pnpm run build --mode embedded     # served at /design-system/ on jjuidev.com
```

Each mode reads its own committed, non-secret `.env.standalone` or
`.env.embedded`: the base path, the origin it is served from, and the origin
search engines are told the content belongs to. `pnpm build` with no mode
builds standalone, and `pnpm dev` serves it too.

## Using the tokens

```tsx
// A component says what a color does.
<button className="bg-primary text-primary-foreground hover:bg-primary-hover">Deploy</button>

// Not this: a raw palette step, which is brand art only.
<button className="bg-primary-700 text-white">Deploy</button>
```

The full set, every rule and every table:
[`docs/conventions/design-tokens-conventions.md`](docs/conventions/design-tokens-conventions.md).

A skin is a set of scale values and nothing else, so the classes above are unchanged by
one: `<html data-skin="spring">` swaps every color scale, status colors included,
for a second palette. Any skin works in either theme.

| Path           | What it is                                                               |
| -------------- | ------------------------------------------------------------------------ |
| `/tokens.json` | Every token as JSON, generated from the same CSS the page parses         |
| `/index.md`    | The token digest as Markdown, identical to the page's "Copy agent brief" |
| `/llms.txt`    | This system as an index an agent can read without running JavaScript     |

All three are generated at build time from `src/styles/`, so they cannot drift
from the styles they describe.

## Components

The catalog, with each component's status and Base UI parts, is in
[`docs/conventions/component-conventions.md`](docs/conventions/component-conventions.md#catalog).

Shipped today: `Button`, `ButtonCopy`, `Popover`, `Logo`, and the non-visual
`Providers`. The catalog also lists what is planned and in what build order.
There is no Storybook yet; the design system page is the catalogue.

## Brand assets

The favicon, the installed icons and the social card in `public/` are generated
from the SVG masters in `scripts/brand-icons/` and committed, so a build needs
no extra tools. After editing a master:

```bash
sh scripts/brand-icons/generate.sh   # needs rsvg-convert, magick, Cascadia Code
```

The mark's geometry:
[`docs/decisions/0005-brand-mark.md`](docs/decisions/0005-brand-mark.md). The SVG
tab icon is tinted at runtime to the app's skin and theme; the other icons and
the social card stay static:
[`docs/decisions/0009-tab-icon-follows-app-skin-and-theme.md`](docs/decisions/0009-tab-icon-follows-app-skin-and-theme.md).

## Checks

| Command              | What it runs                                                     |
| -------------------- | ---------------------------------------------------------------- |
| `pnpm lint`          | ESLint and Stylelint                                             |
| `pnpm typecheck`     | `tsc --noEmit`                                                   |
| `pnpm test`          | Vitest in Browser Mode                                           |
| `pnpm test:coverage` | The same, gated at 90% lines, functions, branches, statements    |
| `pnpm test:e2e`      | Playwright, including an axe run over three pages in both themes |

CI runs all of them, then builds the image and deploys. Run the whole gate
locally before opening a pull request:

```bash
pnpm lint && pnpm typecheck && pnpm test && pnpm test:e2e
```

## Documentation

[`docs/README.md`](docs/README.md) is the map. Conventions live in
[`docs/conventions/`](docs/conventions/README.md) and are the authority for how
code in this repository is written; this README deliberately restates none of
them. [`CONTRIBUTING.md`](CONTRIBUTING.md) covers the contribution workflow.

## Vendored agent tooling

`.claude/`, `.agents/`, `.harness-core/`, `.agentkit/` and `agentkit/` are
third-party agent tooling, committed on purpose so a fresh clone behaves exactly
like this checkout. **They are not covered by this repository's MIT license —
their own licenses apply.** The `files` allowlist in `package.json` is what keeps
them out of any published tarball.

## License

MIT. See [LICENSE](LICENSE).
