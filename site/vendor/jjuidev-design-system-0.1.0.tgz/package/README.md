# jjuidev design system

Design tokens and rules for building UI with Tailwind CSS v4. Tailwind is the
base; a small semantic layer sits on top, so a component says what a color or a
text role **does**, not which shade it is. Every token has a light and a dark
value, and every new text or UI pairing has to meet WCAG 2.2 AA in both.

This repository is the `@jjuidev/design-system` package: tokens, styles, skins,
the theme runtime, the `Button` component, the brand mark component, the theme
and skin toggles, the `jds` CLI, and the `skin-kit`. It is a library, not an
application: it ships no page, no router and no server.

## Use as a package

Import one stylesheet, never both:

```ts
import '@jjuidev/design-system/styles.css'; // precompiled, no build step
// or, in a host that runs Tailwind v4: @import '@jjuidev/design-system/tailwind.css';
```

```tsx
import { defineSkin, ThemeProvider } from '@jjuidev/design-system';

<ThemeProvider skins={[defineSkin({ id: 'shop-ocean', label: 'Ocean' })]}>…</ThemeProvider>;
```

A host imports `cn` and `tv` from the package instead of copying the class helpers: they carry
the merge config that knows the semantic text roles, so a copied helper would drop a text role.

The package carries no fonts; the host loads Be Vietnam Pro, Lora and Cascadia Code, or the stacks fall
back to system fonts. Either link a Google Fonts stylesheet (and allow `fonts.googleapis.com` and
`fonts.gstatic.com` in the host's policy) or load the fonts the host's own way and point the font
tokens at the result. With `next/font`, whose family names are generated:

```css
:root {
	--font-sans: var(--font-be-vietnam-pro), system-ui, sans-serif;
	--font-serif: var(--font-lora), Georgia, serif;
	--font-mono: var(--font-cascadia-code), ui-monospace, monospace;
}
```

Every class of both stylesheets reads `var(--font-*)`, so these three variables are the whole contract.

## What the package exports

| Export                                   | What it is                                                                                                  |
| ---------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `Button`                                 | The component, with the `variant` and `size` axes, an icon slot and a `loading` state                       |
| `Logo`                                   | The brand mark: the mark, the `jjuidev` wordmark and the tagline; collapsed below `48rem` unless `expanded` |
| `ThemeProvider`                          | Owns the theme and the skin; `useTheme()` reads them                                                        |
| `ThemeToggle`                            | The theme menu: light, dark, system                                                                         |
| `SkinToggle`                             | The skin menu; renders nothing when fewer than two skins are registered                                     |
| `useTheme`                               | `{ theme, resolvedTheme, setTheme, skin, skins, setSkin }`                                                  |
| `defineSkin`                             | A typing helper for a host's own skin; it loads no CSS and has no side effect                               |
| `cn`                                     | The class merge helper; it knows the semantic text roles                                                    |
| `tv`                                     | The variant helper, on the same merge config                                                                |
| `parsePreferences`                       | Reads the stored preferences out of a request's cookies, for a server render                                |
| `@jjuidev/design-system/skin-kit`        | `checkSkin`: the contrast contract, for a host's CI                                                         |
| `@jjuidev/design-system/skin-kit/vitest` | `expectSkinToPassContract`: the same contract as a test assertion                                           |
| `@jjuidev/design-system/styles.css`      | The precompiled stylesheet                                                                                  |
| `@jjuidev/design-system/tailwind.css`    | The Tailwind v4 source entry                                                                                |
| `@jjuidev/design-system/skins/*.css`     | The platform skins as plain custom properties                                                               |

A host declares its own skin ids so `setSkin` autocompletes them:

```ts
declare module '@jjuidev/design-system' {
	interface Register {
		skins: [typeof oceanSkin];
	}
}
```

## Skins

A skin is a set of scale values and nothing else, so the classes below are
unchanged by one: `data-skin="spring"` swaps every color scale, status colors
included, for a second palette. Any skin works in either theme. The platform
ships `default` (autumn) and `spring`.

A host's own skin file is held to the same contract as the platform skins, in
the host's CI:

```bash
npx jds skin check src/skin-shop-ocean.css
```

`--separation` adds an advisory: it warns when a brand fill and a status fill
sit too close together in OKLab. Why and how:
[`docs/decisions/0010-skins-and-styles-in-library-mode.md`](docs/decisions/0010-skins-and-styles-in-library-mode.md).

## Using the tokens

```tsx
// A component says what a color does.
<button className="bg-primary text-primary-foreground hover:bg-primary-hover">Deploy</button>

// Not this: a raw palette step, which is brand art only.
<button className="bg-primary-700 text-white">Deploy</button>
```

The full set, every rule and every table:
[`docs/conventions/design-tokens-conventions.md`](docs/conventions/design-tokens-conventions.md).

## Checks

Requires Node 24 and pnpm 11.

```bash
pnpm install         # install dependencies
pnpm build:lib       # build the package into dist/lib
```

| Command              | What it runs                                                   |
| -------------------- | -------------------------------------------------------------- |
| `pnpm lint`          | ESLint and Stylelint                                           |
| `pnpm typecheck`     | `tsc --noEmit`                                                 |
| `pnpm test`          | Vitest in Browser Mode                                         |
| `pnpm test:coverage` | The same, gated at 90% lines, functions, branches, statements  |
| `pnpm test:e2e`      | Playwright: the packed tarball consumed by three consumer apps |
| `pnpm build:lib`     | The package build: components, styles, types, then the layout  |

CI runs all of them. Run the whole gate locally before opening a pull request:

```bash
pnpm lint && pnpm typecheck && pnpm test && pnpm build:lib && pnpm test:e2e
```

## Documentation

[`docs/README.md`](docs/README.md) is the map. Conventions live in
[`docs/conventions/`](docs/conventions/README.md) and are the authority for how
code in this repository is written; this README deliberately restates none of
them. [`CONTRIBUTING.md`](CONTRIBUTING.md) covers the contribution workflow.

## License

MIT. See [LICENSE](LICENSE).
